import React, { useState, useEffect } from 'react';
import { Plan, ViewState } from './types';
import { CreatePlanForm } from './components/CreatePlanForm';
import { PlanCard } from './components/PlanCard';
import { PlanExecutionView } from './components/PlanExecutionView';
import { LoginForm } from './components/LoginForm';
import { Button } from './components/Button';
import { Plus, Compass, LogOut, LayoutDashboard } from 'lucide-react';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [view, setView] = useState<ViewState>('DASHBOARD');
  const [plans, setPlans] = useState<Plan[]>([]);
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);

  useEffect(() => {
    const savedPlans = localStorage.getItem('lider_plans_v2');
    if (savedPlans) {
      try {
        setPlans(JSON.parse(savedPlans));
      } catch (e) {
        console.error("Failed to parse plans", e);
      }
    }
    
    // Check session
    const session = localStorage.getItem('brujula_session');
    if (session === 'active') {
      setIsAuthenticated(true);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('lider_plans_v2', JSON.stringify(plans));
  }, [plans]);

  const handleLogin = () => {
    localStorage.setItem('brujula_session', 'active');
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    localStorage.removeItem('brujula_session');
    setIsAuthenticated(false);
    setView('DASHBOARD');
    setSelectedPlan(null);
  };

  const handleSavePlan = (plan: Plan) => {
    setPlans([plan, ...plans]);
    setView('DASHBOARD');
  };

  const handleUpdatePlan = (updatedPlan: Plan) => {
    const updatedPlans = plans.map(p => p.id === updatedPlan.id ? updatedPlan : p);
    setPlans(updatedPlans);
    setSelectedPlan(updatedPlan); // Keep selected updated
  };

  const handlePlanClick = (plan: Plan) => {
    setSelectedPlan(plan);
    setView('VIEW_PLAN');
  };

  const renderContent = () => {
    if (view === 'CREATE_PLAN') {
      return (
        <div className="max-w-7xl mx-auto h-[calc(100vh-100px)]">
          <CreatePlanForm 
            onSave={handleSavePlan}
            onCancel={() => setView('DASHBOARD')}
          />
        </div>
      );
    }

    if (view === 'VIEW_PLAN' && selectedPlan) {
      return (
        <div className="max-w-full mx-auto">
          <PlanExecutionView 
            plan={selectedPlan}
            onBack={() => setView('DASHBOARD')}
            onUpdatePlan={handleUpdatePlan}
          />
        </div>
      );
    }

    return (
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 tracking-tight">Brújula</h1>
            <p className="text-gray-500 mt-1">Gestión estratégica y operativa.</p>
          </div>
          <Button 
            onClick={() => setView('CREATE_PLAN')} 
            icon={<Plus className="w-5 h-5" />}
            className="shadow-md"
          >
            Nuevo Plan
          </Button>
        </div>

        {plans.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-xl shadow-sm border border-dashed border-gray-300">
            <Compass className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900">Sin planes registrados</h3>
            <div className="mb-6"></div>
            <Button onClick={() => setView('CREATE_PLAN')} variant="secondary">
              Crear Plan
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {plans.map(plan => (
              <PlanCard key={plan.id} plan={plan} onClick={handlePlanClick} />
            ))}
          </div>
        )}
      </div>
    );
  };

  if (!isAuthenticated) {
    return <LoginForm onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col font-sans">
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-full mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center cursor-pointer" onClick={() => setView('DASHBOARD')}>
              <div className="bg-blue-600 p-1.5 rounded mr-2">
                <Compass className="w-6 h-6 text-white" />
              </div>
              <span className="font-bold text-xl text-gray-900 tracking-tight">Brújula</span>
            </div>
            <div className="flex items-center space-x-4">
               <div className="hidden md:flex flex-col items-end mr-2">
                  <span className="text-sm font-medium text-gray-900">Líder de Área</span>
                  <span className="text-xs text-gray-500">Sesión activa</span>
               </div>
               <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-bold text-sm border border-blue-200">
                LA
               </div>
               <button 
                onClick={handleLogout}
                className="text-gray-400 hover:text-red-600 transition-colors p-1"
                title="Cerrar Sesión"
               >
                 <LogOut className="w-5 h-5" />
               </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="flex-1 py-8 px-4 sm:px-6 lg:px-8">
        {renderContent()}
      </main>
    </div>
  );
};

export default App;